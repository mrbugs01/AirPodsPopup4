# AirPods Popup (Android)

AirPods Pro ka connection popup, jo iPhone par milta hai, Android par lane wali app.
Case kholte hi background me BLE se AirPods ka proximity signal padhta hai, popup dikhata hai
(model naam + L/R/Case battery %) aur paired AirPods ko auto-connect karne ki koshish karta hai.

## Kaise chalayein

1. **Android Studio** kholo (latest stable version — Koala ya newer).
2. `AirPodsPopup` folder ko "Open an existing project" se open karo.
3. Gradle sync hone do (internet chahiye, dependencies download hongi).
4. Apne phone ko USB se connect karo, USB debugging ON karo.
5. Run button dabao — app phone par install ho jayegi.
6. App kholo → "Grant Permissions & Start" button dabao → Bluetooth/Location permissions allow karo.
7. Ab AirPods Pro ka case band karke, phone ke paas laa kar khol do — kuch second me popup aayega.

## Zaroori setup (ek baar)

- AirPods ko pehle **Bluetooth Settings me ek baar manually pair** karna hoga (jaise normal
  Bluetooth device pair karte ho). Uske baad hi auto-connect kaam karega.
- Phone me **Location ON** hona chahiye — Android BLE scan ke liye yeh zaroori hai (Android ka
  hi rule hai, GPS use nahi hota).
- App ko "battery ke liye restricted na ho" — Settings → Apps → AirPods Popup → Battery →
  "Unrestricted" karo, warna background me service band ho sakti hai.

## Kaise kaam karta hai (technical)

- AirPods (jab case khula ho ya kaan me na ho) Apple ka proprietary BLE broadcast bhejte hain
  jisko "Proximity Pairing" packet kehte hain (manufacturer ID 0x004C, type 0x07). Yehi packet
  iPhone padh kar apna popup dikhata hai.
- `AirPodsParser.kt` isi packet ko decode karta hai — model, dono earbuds ki battery, case ki
  battery, aur charging status nikalta hai.
- `BleScanService.kt` ek foreground service hai jo continuously BLE scan karta hai. Jab strong
  signal (RSSI > -60, matlab paas me hai) milta hai to popup trigger karta hai.
- `PopupActivity.kt` ek chhota transparent card dikhata hai jo 6 second baad khud band ho jata
  hai — bilkul iPhone jaisa.
- Auto-connect Android ke reflection trick se kiya gaya hai kyunki paired Bluetooth device ko
  force-connect karne ka koi public API nahi hai. Kuch phones (Xiaomi/Samsung heavily
  customized ROMs) isko block kar sakte hain — us case me user ko Bluetooth settings se manually
  tap karna padega.

## Limitations (imaandaari se bata raha hoon)

- Yeh reverse-engineered protocol hai (Apple ne officially publish nahi kiya), isliye:
  - Future AirPods firmware update se packet format change ho sakta hai.
  - Kuch Android phones/OEMs BLE background scan ko aggressively kill karte hain — battery
    optimization off karna zaroori hai.
- 100% guarantee nahi ki har phone par perfectly chale, lekin yehi approach hai jo AirBattery,
  OpenPods jaisi popular apps use karti hain.
