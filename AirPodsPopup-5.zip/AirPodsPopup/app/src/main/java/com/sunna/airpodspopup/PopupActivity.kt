package com.sunna.airpodspopup

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Transparent full-screen activity that shows a small card at the bottom of the
 * screen — mimicking the native iOS AirPods connection popup.
 */
class PopupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        setContentView(R.layout.activity_popup)

        val model = intent.getStringExtra("model") ?: "AirPods"
        val left = intent.getIntExtra("left", -1)
        val right = intent.getIntExtra("right", -1)
        val caseB = intent.getIntExtra("case", -1)
        val leftCharging = intent.getBooleanExtra("leftCharging", false)
        val rightCharging = intent.getBooleanExtra("rightCharging", false)
        val caseCharging = intent.getBooleanExtra("caseCharging", false)

        findViewById<TextView>(R.id.txtModel).text = model
        findViewById<TextView>(R.id.txtLeft).text = "L: " + (if (left >= 0) "$left%" else "--") + (if (leftCharging) " ⚡" else "")
        findViewById<TextView>(R.id.txtRight).text = "R: " + (if (right >= 0) "$right%" else "--") + (if (rightCharging) " ⚡" else "")
        findViewById<TextView>(R.id.txtCase).text = "Case: " + (if (caseB >= 0) "$caseB%" else "--") + (if (caseCharging) " ⚡" else "")

        // Auto-dismiss after 6 seconds, just like iOS
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 6000)
    }
}
