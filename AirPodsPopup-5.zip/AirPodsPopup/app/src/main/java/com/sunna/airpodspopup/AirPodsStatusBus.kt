package com.sunna.airpodspopup

import android.os.Handler
import android.os.Looper

/**
 * Lightweight in-process event bus. BleScanService pushes every parsed AirPodsStatus
 * here; MainActivity (or any other screen) can subscribe to get live updates while
 * it's on screen, and can also read the last known status immediately on open.
 */
object AirPodsStatusBus {

    var lastStatus: AirPodsStatus? = null
        private set

    var lastUpdateTime: Long = 0L
        private set

    private val listeners = mutableListOf<(AirPodsStatus) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun postUpdate(status: AirPodsStatus) {
        lastStatus = status
        lastUpdateTime = System.currentTimeMillis()
        mainHandler.post {
            listeners.forEach { it(status) }
        }
    }

    fun subscribe(listener: (AirPodsStatus) -> Unit) {
        listeners.add(listener)
    }

    fun unsubscribe(listener: (AirPodsStatus) -> Unit) {
        listeners.remove(listener)
    }
}
