package com.sunna.airpodspopup

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Date

class MainActivity : AppCompatActivity() {

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startService(Intent(this, BleScanService::class.java))
            findViewById<TextView>(R.id.txtStatus).text =
                "Scanning in background.\nOpen your AirPods case nearby — popup will appear."
        } else {
            findViewById<TextView>(R.id.txtStatus).text =
                "Permissions needed for Bluetooth scanning to work. Please allow them from Settings."
        }
    }

    // Called whenever the service hears a fresh AirPods broadcast while this screen is open.
    private val statusListener: (AirPodsStatus) -> Unit = { status ->
        runOnUiThread { renderStatus(status) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnGrant).setOnClickListener {
            val perms = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 31) {
                perms.add(Manifest.permission.BLUETOOTH_SCAN)
                perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                perms.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            requestPermissions.launch(perms.toTypedArray())
        }

        // If we already have a last-known reading (from before this screen opened), show it now.
        AirPodsStatusBus.lastStatus?.let { renderStatus(it) }
    }

    override fun onResume() {
        super.onResume()
        AirPodsStatusBus.subscribe(statusListener)
    }

    override fun onPause() {
        super.onPause()
        AirPodsStatusBus.unsubscribe(statusListener)
    }

    private fun renderStatus(status: AirPodsStatus) {
        findViewById<LinearLayout>(R.id.statusCard).visibility = LinearLayout.VISIBLE

        findViewById<TextView>(R.id.txtLiveModel).text = status.modelName

        fun fmt(pct: Int, charging: Boolean): String {
            val value = if (pct >= 0) "$pct%" else "--"
            return if (charging) "$value ⚡" else value
        }

        findViewById<TextView>(R.id.txtLiveLeft).text = "L: " + fmt(status.leftBattery, status.leftCharging)
        findViewById<TextView>(R.id.txtLiveRight).text = "R: " + fmt(status.rightBattery, status.rightCharging)
        findViewById<TextView>(R.id.txtLiveCase).text = "Case: " + fmt(status.caseBattery, status.caseCharging)

        val time = DateFormat.format("hh:mm:ss a", Date(AirPodsStatusBus.lastUpdateTime))
        findViewById<TextView>(R.id.txtLiveUpdated).text = "Last updated: $time"
    }
}
