package com.sunna.airpodspopup

/**
 * Parses Apple's "Proximity Pairing" BLE advertisement (manufacturer id 0x004C, type 0x07).
 * This is the same broadcast iPhones use to show the native AirPods popup.
 * Protocol reverse-engineered by the open-source community (OpenPods / AirBattery style).
 */
data class AirPodsStatus(
    val modelName: String,
    val leftBattery: Int,     // 0-10, -1 = unknown/charging-not-worn
    val rightBattery: Int,
    val caseBattery: Int,
    val leftCharging: Boolean,
    val rightCharging: Boolean,
    val caseCharging: Boolean,
    val isLidOpen: Boolean
)

object AirPodsParser {

    private const val APPLE_MANUFACTURER_ID = 0x004C

    // Known model prefix bytes (first byte of the "device model" field)
    private val MODEL_MAP = mapOf(
        "0220" to "AirPods Pro",
        "0e20" to "AirPods (3rd gen)",
        "0a20" to "AirPods (2nd gen)",
        "1320" to "AirPods Pro 2",
        "1420" to "AirPods Pro 2 (USB-C)",
        "1901" to "AirPods Pro 3",
        "1920" to "AirPods Pro 3"
    )

    fun getManufacturerData(scanRecordBytes: ByteArray?): ByteArray? {
        if (scanRecordBytes == null) return null
        // Manual parse of AD structures to find manufacturer-specific data (type 0xFF)
        var index = 0
        while (index < scanRecordBytes.size) {
            val length = scanRecordBytes[index].toInt() and 0xFF
            if (length == 0) break
            val type = scanRecordBytes[index + 1].toInt() and 0xFF
            if (type == 0xFF) {
                val start = index + 2
                val end = index + 1 + length
                if (end <= scanRecordBytes.size) {
                    return scanRecordBytes.copyOfRange(start, end)
                }
            }
            index += length + 1
        }
        return null
    }

    /**
     * data = raw manufacturer-specific bytes (after the company ID has already been stripped,
     * i.e. data[0]/data[1] == 0x07 0x19 "Proximity Pairing" header)
     */
    fun parse(data: ByteArray): AirPodsStatus? {
        if (data.size < 27) return null

        // Company ID check (first 2 bytes little-endian == 0x004C == Apple)
        val companyId = (data[0].toInt() and 0xFF) or ((data[1].toInt() and 0xFF) shl 8)
        if (companyId != APPLE_MANUFACTURER_ID) return null

        // Byte 2 must be 0x07 (Proximity Pairing message type)
        if ((data[2].toInt() and 0xFF) != 0x07) return null

        val hex = data.joinToString("") { String.format("%02x", it) }
        // hex layout (after company id + type + length, i.e. from index 3 in `data`,
        // or index 8 in the hex string since 4 bytes = 8 hex chars precede it):
        // prefix(2) + devicemodel(4) + status(2) + battery(2) + charge_status(1) + lid_open(1)...
        if (hex.length < 26) return null

        val deviceModelHex = hex.substring(6, 10) // e.g. "0e20" AirPods 3rd gen, "0220" Pro, "1920" Pro3
        val modelName = MODEL_MAP[deviceModelHex] ?: "AirPods (unknown model: $deviceModelHex)"

        val statusByte = hex.substring(10, 12).toInt(16)
        val isLeftFlipped = (statusByte and 0x20) != 0 // pod-swap bit

        val batteryByte = hex.substring(12, 14).toInt(16)
        var leftRaw = (batteryByte and 0xF0) shr 4
        var rightRaw = batteryByte and 0x0F

        val chargeStatusByte = hex.substring(14, 16).toInt(16)
        var leftCharging = (chargeStatusByte and 0x10) != 0
        var rightCharging = (chargeStatusByte and 0x01) != 0
        val caseCharging = (chargeStatusByte and 0x04) != 0

        if (isLeftFlipped) {
            val tmp = leftRaw; leftRaw = rightRaw; rightRaw = tmp
            val tmpC = leftCharging; leftCharging = rightCharging; rightCharging = tmpC
        }

        val caseByteRaw = hex.substring(16, 18).toInt(16) and 0x0F

        fun norm(v: Int) = if (v in 0..10) v * 10 else -1

        val lidByte = hex.substring(18, 20).toInt(16)
        val isLidOpen = (lidByte and 0x08) == 0 // heuristic: bit pattern differs when lid closed

        return AirPodsStatus(
            modelName = modelName,
            leftBattery = norm(leftRaw),
            rightBattery = norm(rightRaw),
            caseBattery = norm(caseByteRaw),
            leftCharging = leftCharging,
            rightCharging = rightCharging,
            caseCharging = caseCharging,
            isLidOpen = isLidOpen
        )
    }
}
