package com.sunna.airpodspopup

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

/**
 * Runs continuously in the background, listens for Apple "Proximity Pairing" BLE
 * broadcasts, and when a strong/fresh signal (case just opened, RSSI spike) is seen,
 * launches the popup + tries to auto-connect the paired AirPods.
 */
class BleScanService : Service() {

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var lastPopupTime = 0L
    private val POPUP_COOLDOWN_MS = 15_000L

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification("Scanning for AirPods…"))
        val btManager = getSystemService(BluetoothManager::class.java)
        bluetoothAdapter = btManager.adapter
        startScan()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun hasScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun startScan() {
        if (!hasScanPermission()) return
        val scanner = bluetoothAdapter.bluetoothLeScanner ?: return
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        scanner.startScan(null, settings, scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val record = result.scanRecord ?: return
            val mfgBytes = AirPodsParser.getManufacturerData(record.bytes) ?: return
            val status = AirPodsParser.parse(mfgBytes) ?: return

            // Only react to a strong, close-by signal (mimics "case just opened near you")
            if (result.rssi < -60) return

            val now = System.currentTimeMillis()
            if (now - lastPopupTime < POPUP_COOLDOWN_MS) return
            lastPopupTime = now

            showPopup(status)
            tryAutoConnect()
        }
    }

    private fun showPopup(status: AirPodsStatus) {
        val i = Intent(this, PopupActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("model", status.modelName)
            putExtra("left", status.leftBattery)
            putExtra("right", status.rightBattery)
            putExtra("case", status.caseBattery)
            putExtra("leftCharging", status.leftCharging)
            putExtra("rightCharging", status.rightCharging)
            putExtra("caseCharging", status.caseCharging)
        }
        startActivity(i)
    }

    private fun tryAutoConnect() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return

        val bondedDevices = bluetoothAdapter.bondedDevices
        val airpodsDevice = bondedDevices?.firstOrNull {
            it.name?.contains("AirPods", ignoreCase = true) == true
        } ?: return

        try {
            // Reflection call to connect A2DP profile proxy — standard trick used by
            // quick-connect apps since there's no public "connect" API for paired devices.
            val method = airpodsDevice.javaClass.getMethod("connect")
            method.invoke(airpodsDevice)
        } catch (e: Exception) {
            // Some OEM ROMs block this; user can tap the device in Bluetooth settings instead.
        }
    }

    private fun buildNotification(text: String): Notification {
        val channelId = "airpods_scan_channel"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "AirPods Scanner", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AirPods Popup")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_headset)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIF_ID = 501
    }
}
