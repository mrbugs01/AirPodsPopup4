package com.sunna.airpodspopup

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Transparent full-screen activity that shows a small card at the bottom of the
 * screen — mimicking the native iOS AirPods connection popup.
 */
class PopupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        setContentView(R.layout.activity_popup)

        val model = intent.getStringExtra("model") ?: "AirPods"
        val left = intent.getIntExtra("left", -1)
        val right = intent.getIntExtra("right", -1)
        val caseB = intent.getIntExtra("case", -1)

        findViewById<TextView>(R.id.txtModel).text = model
        findViewById<TextView>(R.id.txtLeft).text = if (left >= 0) "L: $left%" else "L: --"
        findViewById<TextView>(R.id.txtRight).text = if (right >= 0) "R: $right%" else "R: --"
        findViewById<TextView>(R.id.txtCase).text = if (caseB >= 0) "Case: $caseB%" else "Case: --"

        // Auto-dismiss after 6 seconds, just like iOS
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 6000)
    }
}
